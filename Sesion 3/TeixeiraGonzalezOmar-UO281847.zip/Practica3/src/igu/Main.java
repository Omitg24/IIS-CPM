package igu;

import java.awt.EventQueue;

import logica.Carta;
import logica.Pedido;

/**
 * Titulo: Clase Main
 * 
 * @author UO281847
 * @version 30/09/2021
 */
public class Main {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Pedido pedido = new Pedido();		
		Carta carta = new Carta();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal(carta, pedido);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
