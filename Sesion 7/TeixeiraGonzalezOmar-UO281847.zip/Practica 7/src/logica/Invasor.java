package logica;

/**
 * Titulo: Clase Invasor
 * 
 * @author Omitg
 * @version 28/10/2021
 */
public class Invasor extends Casilla {	
	/**
	 * Constructor del Invasor
	 */
	public Invasor() {
		setPuntos(3000);
	}
}
