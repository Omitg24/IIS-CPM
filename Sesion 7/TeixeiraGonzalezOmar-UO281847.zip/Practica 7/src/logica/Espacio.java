package logica;

/**
 * Titulo: Clase Espacio
 * 
 * @author Omitg
 * @version 28/10/2021
 */
public class Espacio extends Casilla {	
	/**
	 * Constructor del Espacio
	 */
	public Espacio() {
		setPuntos(-200);
	}
}