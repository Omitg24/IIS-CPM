package logica;

/**
 * Titulo: Clase Invasor
 * 
 * @author Omitg
 * @version 21/10/2021 
 */
public class Meteorito extends Casilla {
	/**
	 * Constructor del Invasor
	 */
	public Meteorito() {
		setPuntos(0);
	}
}
